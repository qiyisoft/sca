package com.lagou.rmpoints;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RmOrderApplication {

    public static void main(String[] args) {
        SpringApplication.run(RmOrderApplication.class, args);
    }

}
