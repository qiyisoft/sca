package com.lagou.rmpoints;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RmOrderApplicationTests {

    @Test
    void contextLoads() {
    }

}
