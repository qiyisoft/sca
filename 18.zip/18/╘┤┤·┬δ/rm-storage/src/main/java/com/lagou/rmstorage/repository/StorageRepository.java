package com.lagou.rmstorage.repository;

import com.lagou.rmstorage.entity.Storage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StorageRepository extends JpaRepository<Storage,Integer> {

}
